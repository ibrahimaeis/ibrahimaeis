<div class="col-md-3">
<div class="panel panel-default sidebar-menu">
    <div class="panel-heading">
        <h3 class="panel-title">Product Categories</h3>
    </div>
    <div class="panel-body">
			
        <ul class="nav nav-pills nav-stacked category-menu" align=center>
			  <li><img src='images/cart.png'></li>
            <li><a href="electronics.php">Electronic</a></li>
            <li><a href="toys.php">Toys</a></li>
        </ul>
    </div>
</div></div>