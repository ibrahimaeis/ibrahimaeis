<style>
.button {
    background-color: #4CAF50; 
}
.button2{
    background-color: #8a00e6;
    color: white;
}
.button3{
    background-color: #4c0080;
    color: white;
    height: 50px;
    width: 100px;
}
</style>
<div id="top">
    <div class="container">
        <div class="col-md-6 offer">

            <a href="#" class="btn button">
                Welcome

            </a>

        </div>
        <div class="col-md-6">
            <ul class="menu">
                <li><a href="index.php">Home</a></li>
				  <li><a href="customer_register.php">Register</a></li>
                <li><a href="account.php">My Account</a></li>
                <li><a href="cart.php">Go to Cart</a></li>
                <li><a href="login.php">Login</a></li>
				  <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>


</div>
